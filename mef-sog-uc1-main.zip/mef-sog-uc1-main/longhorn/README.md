# Install

Installation from official website: https://longhorn.io/docs/1.6.1/deploy/install/install-with-helm/
