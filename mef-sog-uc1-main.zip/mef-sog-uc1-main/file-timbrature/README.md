## Test File

In this folder you will find the XML format files of the clockings to be used for the workload.
